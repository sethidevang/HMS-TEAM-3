////////
////////  CreateHospitalView.swift
////////  HMS-Team-3
////////
////////  Created by Devang Sethi on 11/02/25.
////////
//////
//import SwiftUI
//import FirebaseFirestore
//import FirebaseStorage
//import FirebaseCore
//
//// MARK: - FirestoreDataManager
//
//class FirestoreDataManager {
//    let db = Firestore.firestore()
//    let storage = Storage.storage()
//
//    func createHospitalAndAdmin(hospitalName: String, location: GeoPoint, adminName: String, adminEmail: String, adminExperience: Int, adminPhoneNumber: String, idProofData: Data, completion: @escaping (Result<Void, Error>) -> Void) {
//
//        // 1. Create the Admin Document in 'admins' collection
//        let adminRef = db.collection("admins").document() // Generate a new ID
//        let adminData: [String: Any] = [
//            "name": adminName,
//            "email": adminEmail,
//            "experience": adminExperience,
//            "phoneNumber": adminPhoneNumber,
//            "hospitalRef": db.collection("hospitals").document() //Creates a reference for the hospital which will be created in the next step.
//        ]
//
//        adminRef.setData(adminData) { error in
//            if let error = error {
//                completion(.failure(error))
//                return
//            }
//
//            //2. Create the Hospital Document in 'hospitals' collection
//            let hospitalRef = adminData["hospitalRef"] as! DocumentReference
//            let hospitalData: [String: Any] = [
//                "name": hospitalName,
//                "location": location,
//                "admin": adminRef // Reference the admin document we just created
//            ]
//
//            hospitalRef.setData(hospitalData) { error in
//                if let error = error {
//                    completion(.failure(error)) //If this fails, delete the admin document.
//                    adminRef.delete()
//                    return
//                }
//
//
//                // 3. Upload ID Proof to Firebase Storage
//                let storageRef = self.storage.reference().child("hospital_id_proofs/\(adminRef.documentID)") // Customize the path as needed
//
//                let uploadTask = storageRef.putData(idProofData, metadata: nil) { metadata, error in
//                    if let error = error {
//                        completion(.failure(error)) //If this fails, delete both hospital and admin documents.
//                        hospitalRef.delete()
//                        adminRef.delete()
//                        return
//                    }
//                    // 4. Update Hospital Document with Storage URL (optional, but recommended)
//                    storageRef.downloadURL { url, error in
//                        if let error = error {
//                            completion(.failure(error)) //If this fails, delete both hospital and admin documents.
//                            hospitalRef.delete()
//                            adminRef.delete()
//                            return
//                        }
//                        guard let url = url else {
//                            completion(.success(()))
//                            return
//                        }
//                        hospitalRef.updateData(["idProofURL": url.absoluteString]) { error in
//                            if let error = error {
//                                completion(.failure(error)) //If this fails, delete both hospital and admin documents.
//                                hospitalRef.delete()
//                                adminRef.delete()
//                                return
//                            }
//                            completion(.success(()))
//                        }
//                    }
//
//                }
//            }
//        }
//    }
//}
//
//// MARK: - Data Models (in separate files, e.g., Hospital.swift)
//
//struct Hospital: Identifiable, Codable { //Added Codable conformance
//    let id: String
//    let name: String
//    let location: GeoPoint?
//    let admin: DocumentReference?
//    let idProofURL: String? // Added to store the URL
//
//    init(id: String, data: [String: Any]) {
//        self.id = id
//        self.name = data["name"] as? String ?? ""
//        self.location = data["location"] as? GeoPoint
//        self.admin = data["admin"] as? DocumentReference
//        self.idProofURL = data["idProofURL"] as? String
//    }
//
//    //Added this initializer to decode from Firestore
//    init(from decoder: Decoder) throws {
//        let container = try decoder.container(keyedBy: CodingKeys.self)
//        self.id = try container.decode(String.self, forKey: .id)
//        self.name = try container.decode(String.self, forKey: .name)
//        self.location = try container.decodeIfPresent(GeoPoint.self, forKey: .location)
//        self.admin = try container.decodeIfPresent(DocumentReference.self, forKey: .admin)
//        self.idProofURL = try container.decodeIfPresent(String.self, forKey: .idProofURL)
//    }
//
//    func encode(to encoder: Encoder) throws {
//        var container = encoder.container(keyedBy: CodingKeys.self)
//        try container.encode(id, forKey: .id)
//        try container.encode(name, forKey: .name)
//        try container.encodeIfPresent(location, forKey: .location)
//        try container.encodeIfPresent(admin, forKey: .admin)
//        try container.encodeIfPresent(idProofURL, forKey: .idProofURL)
//    }
//
//    private enum CodingKeys: String, CodingKey {
//        case id
//        case name
//        case location
//        case admin
//        case idProofURL
//    }
//
//}
//
//
//struct Admin: Identifiable, Codable { //Added Codable conformance
//    let id: String
//    let name: String
//    let email: String
//    let experience: Int
//    let phoneNumber: String
////    let hospitalRef: DocumentReference
//
//    init(id: String, data: [String: Any]) {
//        self.id = id
//        self.name = data["name"] as? String ?? ""
//        self.email = data["email"] as? String ?? ""
//        self.experience = data["experience"] as? Int ?? 0
//        self.phoneNumber = data["phoneNumber"] as? String ?? ""
//        self.hospitalRef = data["hospitalRef"] as? DocumentReference ?? DocumentReference()
//    }
//
//    //Added this initializer to decode from Firestore
//    init(from decoder: Decoder) throws {
//        let container = try decoder.container(keyedBy: CodingKeys.self)
//        self.id = try container.decode(String.self, forKey: .id)
//        self.name = try container.decode(String.self, forKey: .name)
//        self.email = try container.decode(String.self, forKey: .email)
//        self.experience = try container.decode(Int.self, forKey: .experience)
//        self.phoneNumber = try container.decode(String.self, forKey: .phoneNumber)
//        self.hospitalRef = try container.decode(DocumentReference.self, forKey: .hospitalRef)
//    }
//
//    func encode(to encoder: Encoder) throws {
//        var container = encoder.container(keyedBy: CodingKeys.self)
//        try container.encode(id, forKey: .id)
//        try container.encode(name, forKey: .name)
//        try container.encode(email, forKey: .email)
//        try container.encode(experience, forKey: .experience)
//        try container.encode(phoneNumber, forKey: .phoneNumber)
//        try container.encode(hospitalRef, forKey: .hospitalRef)
//    }
//
//    private enum CodingKeys: String, CodingKey {
//        case id
//        case name
//        case email
//        case experience
//        case phoneNumber
//        case hospitalRef
//    }
//}
//
//// ... other data models (User, etc.)
//
//// MARK: - SwiftUI View
//
//struct CreateHospitalView: View {
//    @ObservedObject var viewModel = CreateHospitalViewModel() // Use an @ObservedObject
//
//    var body: some View {
//        Form {
//            TextField("Hospital Name", text: $viewModel.hospitalName)
//
//            // Location (using two separate fields for latitude and longitude)
//            TextField("Latitude", value: $viewModel.latitude, format: .number)
//            TextField("Longitude", value: $viewModel.longitude, format: .number)
//
//            TextField("Admin Name", text: $viewModel.adminName)
//            TextField("Admin Email", text: $viewModel.adminEmail)
//            TextField("Admin Experience", value: $viewModel.adminExperience, format: .number)
//            TextField("Admin Phone Number", text: $viewModel.adminPhoneNumber)
//
//            // ID Proof Upload (using a button and displaying the selected file name)
//            Button("Upload ID Proof") {
//                viewModel.isPickingDocument = true
//            }
//            .sheet(isPresented: $viewModel.isPickingDocument) {
//                DocumentPicker(selectedURL: $viewModel.idProofURL, selectedData: $viewModel.idProofData)
//            }
//
//            if let fileName = viewModel.idProofURL?.lastPathComponent {
//                Text("Selected File: \(fileName)")
//            }
//
//            Button("Create Hospital and Admin") {
//                viewModel.createHospitalAndAdmin()
//            }
//            .disabled(!viewModel.isFormValid) // Disable button until form is valid
//
//            // Display error message if any
//            if let errorMessage = viewModel.errorMessage {
//                Text(errorMessage)
//                    .foregroundColor(.red)
//            }
//            if viewModel.isSuccess {
//                Text("Hospital and admin created successfully!")
//                    .foregroundColor(.green)
//            }
//        }
//        .navigationTitle("Create Hospital")
//    }
//}
//
//
//// MARK: - ViewModel
//
//class CreateHospitalViewModel: ObservableObject {
//    @Published var hospitalName: String = ""
//    @Published var latitude: Double = 0.0
//    @Published var longitude: Double = 0.0
//    @Published var adminName: String = ""
//    @Published var adminEmail: String = ""
//    @Published var adminExperience: Int = 0
//    @Published var adminPhoneNumber: String = ""
//    @Published var idProofURL: URL?
//    @Published var idProofData: Data?
//    @Published var errorMessage: String? = nil
//    @Published var isPickingDocument = false
//    @Published var isSuccess = false
//
//    private let dataManager = FirestoreDataManager()
//
//    var isFormValid: Bool {
//        !hospitalName.isEmpty && latitude != 0 && longitude != 0 && !adminName.isEmpty && !adminEmail.isEmpty && !adminPhoneNumber.isEmpty && idProofData != nil
//    }
//
//    func createHospitalAndAdmin() {
//        guard let location = GeoPoint(latitude: latitude, longitude: longitude),
//              let idProofData = idProofData else {
//            errorMessage = "Invalid input data."
//            return
//        }
//
//        errorMessage = nil // Clear any previous errors
//        isSuccess = false
//
//        dataManager.createHospitalAndAdmin(hospitalName: hospitalName, location: location, adminName: adminName, adminEmail: adminEmail, adminExperience: adminExperience, adminPhoneNumber: adminPhoneNumber, idProofData: idProofData) { result in
//            DispatchQueue.main.async { //Update UI on main thread
//                switch result {
//                case .success():
//                    self.isSuccess = true
//                    self.hospitalName = ""
//                    self.latitude = 0.0
//                    self.longitude = 0.0
//                    self.adminName = ""
//                    self.adminEmail = ""
//                    self.adminExperience = 0
//                    self.adminPhoneNumber = ""
//                    self.idProofURL = nil
//                    self.idProofData = nil
//
//                case .failure(let error):
//                    self.errorMessage = error.localizedDescription
//                }
//            }
//        }
//    }
//}
//
//// MARK: - Document Picker (Reusable component)
//
//struct DocumentPicker: UIViewControllerRepresentable {
//    @Binding var selectedURL: URL?
//    @Binding var selectedData: Data?
//
//    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
//        let controller = UIDocumentPickerViewController(forOpeningContentTypes: [.pdf, .jpg, .jpeg, .png]) // Add other types if needed
//        controller.delegate = context.coordinator
//        return controller
//    }
//
//    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
//
//    func makeCoordinator() -> Coordinator {
//        Coordinator(self)
//    }
//
//    class Coordinator: NSObject, UIDocumentPickerDelegate {
//        let parent: DocumentPicker
//
//        init(_ parent: DocumentPicker) {
//            self.parent = parent
//        }
//
//        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
//            guard let url = urls.first else { return }
//            parent.selectedURL = url
//            do {
//                parent.selectedData = try Data(contentsOf: url)
//            } catch {
//                print("Error loading data: \(error)")
//                // Handle error appropriately (e.g., display an alert to the user)
//            }
//        }
//    }
//}
//
//
//#Preview {
//    CreateHospitalView()
//}
