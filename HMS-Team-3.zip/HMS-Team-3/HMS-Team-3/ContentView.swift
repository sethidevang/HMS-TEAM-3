////
////  ContentView.swift
////  HMS-Team-3
////
////  Created by Devang Sethi on 11/02/25.
////
//
//

import SwiftUI
//import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

//struct ContentView
//import FirebaseAuth
//import FirebaseFirestore
//import FirebaseFirestoreSwift
//
//struct ContentView: View {
////    @State private var email = ""
////    @State private var password = ""
////    @State private var isLoggedIn = false
////    @State private var hospitals: [Hospital] = []
////    
////    var body: some View {
////        NavigationView {
////            if isLoggedIn {
////                HospitalListView(hospitals: hospitals)
////            } else {
////                VStack {
////                    Text("Hospital Management System")
////                        .font(.largeTitle)
////                        .padding()
////                    
////                    TextField("Email", text: $email)
////                        .textFieldStyle(RoundedBorderTextFieldStyle())
////                        .padding()
////                        .autocapitalization(.none)
////                        .keyboardType(.emailAddress)
////                    
////                    SecureField("Password", text: $password)
////                        .textFieldStyle(RoundedBorderTextFieldStyle())
////                        .padding()
////                    
////                    Button(action: login) {
////                        Text("Login")
////                            .padding()
////                            .frame(maxWidth: .infinity)
////                            .background(Color.blue)
////                            .foregroundColor(.white)
////                            .cornerRadius(10)
////                    }
////                    .padding()
////                }
////                .padding()
////            }
////        }
////    }
////    
////    func login() {
////        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
////            if let error = error {
////                print("Login failed: \(error.localizedDescription)")
////            } else {
////                isLoggedIn = true
////                fetchHospitals()
////            }
////        }
////    }
////    
////    func fetchHospitals() {
////        let db = Firestore.firestore()
////        db.collection("hospitals").addSnapshotListener { snapshot, error in
////            if let error = error {
////                print("Error fetching hospitals: \(error.localizedDescription)")
////            } else {
////                hospitals = snapshot?.documents.compactMap { doc -> Hospital? in
////                    let data = doc.data()
////                    guard let name = data["name"] as? String,
////                          let location = data["location"] as? String else { return nil }
////                    return Hospital(name: name, location: location, admin: Admin(id: UUID(), name: "", email: "", phoneNumber: "", identity: Data()))
////                } ?? []
////            }
////        }
////    }
////}
////
////struct HospitalListView: View {
////    let hospitals: [Hospital]
////    
////    var body: some View {
////        List(hospitals, id: \.id) { hospital in
////            VStack(alignment: .leading) {
////                Text(hospital.name).font(.headline)
////                Text(hospital.location).font(.subheadline)
////            }
////        }
////        .navigationTitle("Hospitals")
////    }
//}
//
////import SwiftUI
////import FirebaseCore
////
////
//////class AppDelegate: NSObject, UIApplicationDelegate {
//////  func application(_ application: UIApplication,
//////                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
//////    FirebaseApp.configure()
//////
//////    return true
//////  }
//////}
//////import SwiftUI
////
////import SwiftUI
////
////struct ContentView: View {
////    @State private var email: String = ""
////    @State private var password: String = ""
////    @State private var isAuthenticated: Bool = false
////    @State private var hospitals: [Hospital] = []
////    
////    private let authService = AuthService()
////    private let hospitalManager = HospitalManagement()
////    
////    var body: some View {
////        NavigationView {
////            if isAuthenticated {
////                VStack {
////                    Text("Hospital Management System")
////                        .font(.largeTitle)
////                        .padding()
////                    
////                    List(hospitals, id: \..id) { hospital in
////                        VStack(alignment: .leading) {
////                            Text(hospital.name)
////                                .font(.headline)
////                            Text(hospital.location)
////                                .font(.subheadline)
////                        }
////                    }
////                    .onAppear { hospitals = hospitalManager.getAllHospitals() }
////                    
////                    Button("Logout") {
////                        isAuthenticated = false
////                    }
////                    .padding()
////                    .background(Color.red)
////                    .foregroundColor(.white)
////                    .cornerRadius(10)
////                }
////            } else {
////                VStack {
////                    Text("Admin Login")
////                        .font(.largeTitle)
////                        .padding()
////                    
////                    TextField("Email", text: $email)
////                        .textFieldStyle(RoundedBorderTextFieldStyle())
////                        .padding()
////                    
////                    SecureField("Password", text: $password)
////                        .textFieldStyle(RoundedBorderTextFieldStyle())
////                        .padding()
////                    
////                    Button("Login") {
////                        if authService.login(email: email, password: password) {
////                            isAuthenticated = true
////                            hospitals = hospitalManager.getAllHospitals()
////                        } else {
////                            print("Invalid credentials")
////                        }
////                    }
////                    .padding()
////                    .background(Color.blue)
////                    .foregroundColor(.white)
////                    .cornerRadius(10)
////                }
////                .padding()
////            }
////        }
////    }
////}
////
////struct ContentView_Previews: PreviewProvider {
////    static var previews: some View {
////        ContentView()
////    }
////}
////
