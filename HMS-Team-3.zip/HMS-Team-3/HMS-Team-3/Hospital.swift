////
////  Hospital.swift
////  HMS-Team-3
////
////  Created by Devang Sethi on 11/02/25.
////
//import SwiftUI
////import FirebaseFirestore
//
////struct Hospital: Identifiable {
////    let id: String
////    let name: String
////    let location: GeoPoint?
////    let admin: DocumentReference?
////
////    init(id: String, data: [String: Any]) {
////        self.id = id
////        self.name = data["name"] as? String ?? ""
////        self.location = data["location"] as? GeoPoint
////        self.admin = data["admin"] as? DocumentReference
////    }
////}
//
//
////super admin work
////struct addHospitalsAndAdmin {
////    let id : UUID = UUID()
////    let name : String
////    let location : String
////    let adminName : String
////    let email : String
////    let phoneNumber : String
////    let identity : Data
////    let staff : Bool
////}
//struct SuperAdmin {
//    let email: String
//    var password: String
//}
//
//class AuthService {
//    private var superAdmin = SuperAdmin(email: "admin@hospital.com", password: "SecurePass123")
//
//    func login(email: String, password: String) -> Bool {
//        return email == superAdmin.email && password == superAdmin.password
//    }
//
//    func changePassword(newPassword: String) {
//        superAdmin.password = newPassword
//        print("Password updated successfully!")
//    }
//}
//
//
//struct Hospital {
//    let id: UUID = UUID()
//    var name: String
//    var location: String
//    let admin: Admin // Unique admin assigned to each hospital
//}
//
//struct Admin {
//    let id: UUID = UUID()
//    let name: String
//    let email: String
//    let phoneNumber: String
//    let identity: Data
//}
//
//class HospitalManagement {
//    private var hospitals: [Hospital] = []
//    private var assignedAdmins: Set<UUID> = [] // Track assigned admins
//
//    // ✅ Create a hospital & assign a unique admin
//    func createHospital(name: String, location: String, admin: Admin) -> Hospital? {
//        if assignedAdmins.contains(admin.id) {
//            print("Error: Admin is already assigned to another hospital!")
//            return nil
//        }
//        
//        let newHospital = Hospital(name: name, location: location, admin: admin)
//        hospitals.append(newHospital)
//        assignedAdmins.insert(admin.id)
//        return newHospital
//    }
//
//    // ✅ Read all hospitals
//    func getAllHospitals() -> [Hospital] {
//        return hospitals
//    }
//
//    // ✅ Update hospital details
//    func updateHospital(id: UUID, name: String?, location: String?) -> Bool {
//        if let index = hospitals.firstIndex(where: { $0.id == id }) {
//            var hospital = hospitals[index]
//            if let newName = name { hospital.name = newName }
//            if let newLocation = location { hospital.location = newLocation }
//            hospitals[index] = hospital
//            return true
//        }
//        return false
//    }
//
//    // ✅ Delete a hospital
//    func deleteHospital(by id: UUID) -> Bool {
//        if let index = hospitals.firstIndex(where: { $0.id == id }) {
//            let removedHospital = hospitals.remove(at: index)
//            assignedAdmins.remove(removedHospital.admin.id)
//            return true
//        }
//        return false
//    }
//    
//    func searchHospital(query: String) -> [Hospital] {
//        return hospitals.filter {
//            $0.name.lowercased().contains(query.lowercased()) ||
//            $0.location.lowercased().contains(query.lowercased())
//        }
//    }
//
//   
//
//}
//
//
//
//
//
////admin work
////struct addDoctor {
////    var name: String
////    var specialization: String
////    var address: String
////    var experience: Int
////    var contactInfo: String
////    var degree: String
////    var idProof: String
////    var bankAccountDetails: String
////    var isStaff: Bool = true  // Default value set to true
////}
//
