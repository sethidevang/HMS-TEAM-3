//
//  SuperAdminProfile.swift
//  HMS-Team3
//
//  Created by DIWAKAR KUMAR on 12/02/25.
//

import SwiftUI
import Firebase
import FirebaseAuth


struct SuperAdminProfile: View {
    @State private var isLoggedOut = false
    var email: String = "Super Admin"
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Spacer().frame(height: 40)
                
                VStack {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .foregroundColor(.gray)
                    
                    Text(email)
                        .font(.headline)
                        .foregroundColor(.black)
                }
                .padding(.bottom, 20)
                
                List {
                    NavigationLink(destination: SuperAdminChangePassword()) {
                        HStack {
                            Text("Change Password")
                            Spacer()
                        }
                    }
                }
                .frame(height: 50)
                .listStyle(PlainListStyle())
                
                Button(action: logOut) {
                    Text("Log Out")
                        .foregroundColor(.red)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.white)
                        .cornerRadius(10)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.red, lineWidth: 1))
                }
                .padding()
                
                Spacer()
            }
            .background(Color(.systemGray6))
            .fullScreenCover(isPresented: $isLoggedOut) {
                LoginView() // Redirects user to login after logout
            }
        }
    }
    
    func logOut() {
        do {
            try Auth.auth().signOut()
            isLoggedOut = true // Redirect user to login
        } catch {
            print("Error signing out: \(error.localizedDescription)")
        }
    }
}

struct SuperAdminProfile_Previews: PreviewProvider {
    static var previews: some View {
        SuperAdminProfile()
    }
}
