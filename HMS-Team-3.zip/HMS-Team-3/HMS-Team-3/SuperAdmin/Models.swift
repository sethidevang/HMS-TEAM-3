//
//  Models.swift
//  HMS-Team3
//
//  Created by DIWAKAR KUMAR on 12/02/25.
//
import FirebaseFirestore
//import FirebaseFirestoreSwift

import Foundation
struct Hospital: Identifiable, Codable {
    @DocumentID var id: String?
    var name: String
    var location: String
    var admin: Admin
    var revenue : String?
    var unpaidDues: String?
    var expenses: String?
}

struct Admin: Codable, Identifiable {
    var id: String? // Optional ID
    var name: String
    var email: String
    var address: String
    var experience: String
    var phoneNumber: String

    // 🔹 Add this explicit initializer
    init(id: String? = nil, name: String, email: String, address: String, experience: String, phoneNumber: String) {
        self.id = id
        self.name = name
        self.email = email
        self.address = address
        self.experience = experience
        self.phoneNumber = phoneNumber
    }

    // 🔹 Convert to Dictionary for Firestore
    func toDictionary() -> [String: Any] {
        return [
            "id": id ?? UUID().uuidString,
            "name": name,
            "email": email,
            "address": address,
            "experience": experience,
            "phoneNumber": phoneNumber
        ]
    }

    // 🔹 Initialize from Firestore Dictionary
    init?(dictionary: [String: Any]) {
        guard let name = dictionary["name"] as? String,
              let email = dictionary["email"] as? String,
              let address = dictionary["address"] as? String,
              let experience = dictionary["experience"] as? String,
              let phoneNumber = dictionary["phoneNumber"] as? String else {
            return nil
        }
        self.id = dictionary["id"] as? String
        self.name = name
        self.email = email
        self.address = address
        self.experience = experience
        self.phoneNumber = phoneNumber
    }
}


//func fetchHospitals() {
//    let db = Firestore.firestore()
//    db.collection("hospitals").getDocuments { snapshot, error in
//        if let error = error {
//            print("Error fetching hospitals: \(error)")
//            return
//        }
//        
//        if let snapshot = snapshot {
//            let hospitals = snapshot.documents.compactMap { doc -> Hospital? in
//                try? doc.data(as: Hospital.self)
//            }
//            print(hospitals)  // Debugging output
//        }
//    }
//}
//
//
//
