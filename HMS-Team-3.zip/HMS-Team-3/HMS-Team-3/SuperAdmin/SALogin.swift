import SwiftUI
import Firebase
import FirebaseFirestore

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage = ""
    @State private var isAuthenticated = false
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        VStack {
            if isAuthenticated {
                SuperAdminDashboardView()
            } else {
                loginForm
            }
        }
        .background(Color(UIColor.systemGray6).edgesIgnoringSafeArea(.all))
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Alert"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }

    var loginForm: some View {
        VStack {
            Spacer()

            Text("Log In")
                .font(.largeTitle)
                .fontWeight(.bold)

            VStack(alignment: .leading, spacing: 15) {
                Text("Email")
                    .fontWeight(.medium)

                TextField("Enter your email", text: $email)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(8)
                    .shadow(radius: 1)

                Text("Password")
                    .fontWeight(.medium)

                SecureField("Enter your password", text: $password)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(8)
                    .shadow(radius: 1)
            }
            .padding(.horizontal, 30)

            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.top, 5)
            }

            HStack {
                Spacer()
                Button(action: {
                    showAlertMessage("Please contact the developer team for password recovery.")
                }) {
                    Text("Forgot Password?")
                        .foregroundColor(.blue)
                }
            }
            .padding(.horizontal, 30)
            .padding(.top, 5)

            Button(action: loginUser) {
                Text("Log In")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .padding(.horizontal, 30)
            .padding(.top, 20)

            Spacer()
        }
    }

    func loginUser() {
        guard !email.isEmpty, !password.isEmpty else {
            showAlertMessage("All fields are required.")
            return
        }

        let db = Firestore.firestore()
        db.collection("superAdmins").whereField("email", isEqualTo: email).getDocuments { snapshot, error in
            if let error = error {
                showAlertMessage("Error: \(error.localizedDescription)")
                return
            }

            guard let documents = snapshot?.documents, let document = documents.first else {
                showAlertMessage("Invalid email or password.")
                return
            }

            let storedPassword = document.data()["password"] as? String ?? ""

            if password == storedPassword {  // Directly match password
                isAuthenticated = true
                errorMessage = ""

                // Set session timeout (5 hours)
                DispatchQueue.main.asyncAfter(deadline: .now() + (5 * 3600)) {
                    isAuthenticated = false
                }
            } else {
                showAlertMessage("Invalid email or password.")
            }
        }
    }

    func showAlertMessage(_ message: String) {
        alertMessage = message
        showAlert = true
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
