//
//  User.swift
//  HMS-Team-3
//
//  Created by Devang Sethi on 11/02/25.
//

//import FirebaseFirestore

//struct User: Identifiable {
//    let id: String
//    let role: String
//    let name: String
//    let email: String
//    let experience: Int?
//    let phoneNumber: String?
//    let hospital: DocumentReference?
//    let idProofURL: String?
//    let staff: Bool?
//
//    init(id: String, data: [String: Any]) {
//        self.id = id
//        self.role = data["role"] as? String ?? ""
//        self.name = data["name"] as? String ?? ""
//        self.email = data["email"] as? String ?? ""
//        self.experience = data["experience"] as? Int
//        self.phoneNumber = data["phoneNumber"] as? String
//        self.hospital = data["hospital"] as? DocumentReference
//        self.idProofURL = data["idProofURL"] as? String
//        self.staff = data["staff"] as? Bool
//    }
//}
