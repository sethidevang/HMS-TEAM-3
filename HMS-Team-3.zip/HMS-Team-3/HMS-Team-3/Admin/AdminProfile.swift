import SwiftUI


struct AdminProfile: View {
    var body: some View {
        VStack(spacing: 20) {
            // Profile Header
            VStack(spacing: 8) {
                Circle()
                    .fill(Color(.systemGray4))
                    .frame(width: 90, height: 90)
                    .overlay(
                        Text("A")
                            .font(.title)
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                    )
                
                Text("admin@gmail.com")
                    .font(.body)
                    .foregroundColor(.black)
            }
            .padding(.top, 8) // Adjusted padding to reduce gap

            // Profile Options
            VStack(spacing: 10) {
                NavigationLink(destination: AdminChangePassword()) {
                    ProfileOption(title: "Change Password")
                }
                
                Button(action: {
                    // Log out action
                }) {
                    Text("Log Out")
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(12)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.red, lineWidth: 0))
                }
            }
            .padding(.horizontal)

            Spacer()
        }
        .background(Color(.systemGray6)) // F2F2F7 background
        .navigationBarTitle("Profile", displayMode: .large) // Keeps large title
    }
}


// MARK: - Profile Option Component
struct ProfileOption: View {
    let title: String
    
    var body: some View {
        HStack {
            Text(title)
                .foregroundColor(.black)
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.gray.opacity(0.1), radius: 3, x: 0, y: 1)
    }
}

// MARK: - Preview
struct AdminProfile_Previews: PreviewProvider {
    static var previews: some View {
        AdminProfile()
    }
}
