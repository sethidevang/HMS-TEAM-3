import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth
import Charts

struct AdminDashboardView: View {
    @StateObject private var viewModel = AdminDashboardViewModel()

    var body: some View {
        TabView {
            NavigationStack {
                DashboardView(viewModel: viewModel)
            }
            .tabItem {
                Image(systemName: "house.fill")
                Text("Dashboard")
            }
            
            NavigationStack {
                Doctor()
            }
            .tabItem {
                Image(systemName: "person.2.fill")
                Text("Doctors")
            }
            
            NavigationStack {
                AdminProfile()
            }
            .tabItem {
                Image(systemName: "person.crop.circle.fill")
                Text("Profile")
            }
        }
        .background(Color(.systemGray6))
        .onAppear {
            viewModel.fetchHospitalForAdmin()
        }
    }
}

// MARK: - Dashboard View
struct DashboardView: View {
    @ObservedObject var viewModel: AdminDashboardViewModel

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // **Header - Hospital Name**
                HStack {
                    Text(viewModel.hospitalName.isEmpty ? "Loading..." : viewModel.hospitalName)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    Spacer()
                }
                .padding(.horizontal)

                // **Bar Chart**
                AdminChartView(revenue: viewModel.totalRevenue, dues: viewModel.unpaidDues, expenses: viewModel.expenses)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color.white)
                            .shadow(color: Color.black.opacity(0.1), radius: 3)
                    )
                    .padding(.horizontal)

                // **Financial Overview**
                HStack(spacing: 12) {
                    FinanceCard(title: "Total Revenue", amount: "$\(viewModel.totalRevenue)", color: .green)
                    FinanceCard(title: "Unpaid Dues", amount: "$\(viewModel.unpaidDues)", color: .blue)
                    FinanceCard(title: "Expenses", amount: "$\(viewModel.expenses)", color: .red)
                }
                .padding(.horizontal)

                // **Activity Overview**
                VStack(alignment: .leading, spacing: 8) {
                    Text("Activity Overview")
                        .font(.headline)
                        .padding(.horizontal)

                    HStack(spacing: 12) {
                        ActivityCard(icon: "stethoscope", label: "\(viewModel.doctorCount)", description: "Doctors", color: .blue.opacity(0.2))
                        ActivityCard(icon: "person.2.fill", label: "50", description: "New Patients", color: .green.opacity(0.2)) // Placeholder
                    }
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white)
                        .shadow(color: Color.black.opacity(0.1), radius: 3)
                )
                .padding(.horizontal)

                Spacer()
            }
            .padding(.top)
        }
        .background(Color(.systemGray6))
    }
}

// MARK: - ViewModel for Firestore Data Fetching
class AdminDashboardViewModel: ObservableObject {
    @Published var hospitalName: String = "Loading..."
    @Published var totalRevenue: Double = 0.0
    @Published var unpaidDues: Double = 0.0
    @Published var expenses: Double = 0.0
    @Published var doctorCount: Int = 0
    @Published var hospitalId: String? = nil

    private let db = Firestore.firestore()

    /// **Fetch Hospital Assigned to Admin**
    func fetchHospitalForAdmin() {
        guard let adminId = Auth.auth().currentUser?.uid else {
            print("No admin logged in")
            return
        }

        db.collection("hospitals").getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching hospitals: \(error.localizedDescription)")
                return
            }

            for document in snapshot?.documents ?? [] {
                let hospitalData = document.data()
                if let previousAdmins = hospitalData["previousAdmins"] as? [[String: Any]] {
                    for admin in previousAdmins {
                        if let id = admin["id"] as? String, id == adminId {
                            DispatchQueue.main.async {
                                self.hospitalId = document.documentID
                                self.hospitalName = hospitalData["name"] as? String ?? "Unknown Hospital"
                                self.fetchHospitalData()
                                self.fetchDoctorCount()
                            }
                            return
                        }
                    }
                }
            }

            print("No hospital found for admin")
        }
    }

    /// **Fetch Hospital Financial Data**
    func fetchHospitalData() {
        guard let hospitalId = hospitalId else { return }
        
        db.collection("hospitals").document(hospitalId).getDocument { document, error in
            if let error = error {
                print("Error fetching hospital data: \(error.localizedDescription)")
                return
            }

            if let data = document?.data() {
                DispatchQueue.main.async {
                    self.totalRevenue = data["totalRevenue"] as? Double ?? 0.0
                    self.unpaidDues = data["unpaidDues"] as? Double ?? 0.0
                    self.expenses = data["expenses"] as? Double ?? 0.0
                }
            }
        }
    }

    /// **Fetch Number of Doctors in the Hospital**
    func fetchDoctorCount() {
        guard let hospitalId = hospitalId else { return }

        db.collection("doctors").whereField("hospitalId", isEqualTo: hospitalId).getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching doctors: \(error.localizedDescription)")
                return
            }

            DispatchQueue.main.async {
                self.doctorCount = snapshot?.documents.count ?? 0
            }
        }
    }
}

// MARK: - Finance Card
struct FinanceCard: View {
    var title: String
    var amount: String
    var color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)

            Text(amount)
                .font(.title3)
                .fontWeight(.bold)
                .foregroundColor(color)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 100)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.1), radius: 3)
        )
    }
}

struct AdminChartView: View {
    var revenue: Double
    var dues: Double
    var expenses: Double

    var body: some View {
        VStack {
            Text(formattedDate())
                .font(.headline)
                .padding(.bottom, 8)

            Chart {
                BarMark(x: .value("Category", "Revenue"), y: .value("Amount", revenue))
                    .foregroundStyle(.green)
                BarMark(x: .value("Category", "Dues"), y: .value("Amount", dues))
                    .foregroundStyle(.blue)
                BarMark(x: .value("Category", "Expenses"), y: .value("Amount", expenses))
                    .foregroundStyle(.red)
            }
            .frame(height: 150)
        }
    }
}

// Function to format date
func formattedDate() -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "dd MMM yyyy"
    return formatter.string(from: Date())
}
// MARK: - Activity Card
struct ActivityCard: View {
    var icon: String
    var label: String
    var description: String
    var color: Color
    
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.largeTitle)
                .foregroundColor(.black)
            Text(label)
                .font(.title3)
                .fontWeight(.bold)
            Text(description)
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(color)
                .shadow(color: Color.black.opacity(0.1), radius: 3)
        )
    }
}

// Preview
struct AdminDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        AdminDashboardView()
    }
}

//func formattedDate() -> String {
//    let formatter = DateFormatter()
//    formatter.dateFormat = "dd MMM yyyy"
//    return formatter.string(from: Date())
//}
