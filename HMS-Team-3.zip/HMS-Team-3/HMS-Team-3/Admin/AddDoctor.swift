import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseStorage
import UIKit
struct AddDoctor: View {
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var specialization = "Select"
    @State private var phone = ""
    @State private var email = ""
    @State private var address = ""
    @State private var experience = ""
    @State private var medicalLicenseId = ""
    @State private var bankAccountNumber = ""
    @State private var degrees: [String] = []
    @State private var selectedImage: UIImage? = nil
    @State private var showImagePicker = false
    @State private var showActionSheet = false
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var specializations = ["Select", "Cardiology", "Neurology", "Pediatrics", "Orthopedics"]
    @State private var hospitalId: String = "hospital123" // Assign hospitalId dynamically

    @Environment(\.presentationMode) var presentationMode

    private var isFormComplete: Bool {
        return !firstName.isEmpty &&
               !lastName.isEmpty &&
               specialization != "Select" &&
               !phone.isEmpty &&
               !email.isEmpty &&
               !address.isEmpty &&
               !experience.isEmpty &&
               !medicalLicenseId.isEmpty &&
               !bankAccountNumber.isEmpty &&
               !degrees.isEmpty &&
               !degrees.contains(where: { $0.isEmpty }) &&
               !hospitalId.isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    VStack {
                        Button(action: {
                            showActionSheet = true
                        }) {
                            if let image = selectedImage {
                                Image(uiImage: image)
                                    .resizable()
                                    .frame(width: 150, height: 150)
                                    .clipShape(Circle())
                            } else {
                                Circle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 150, height: 150)
                            }
                        }
                        Text("Add Photo")
                            .foregroundColor(.blue)
                            .font(.caption)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical)
                }
                .listRowBackground(Color.clear)

                Section(header: Text("Personal Information")) {
                    TextField("First Name", text: $firstName)
                    TextField("Last Name", text: $lastName)

                    Picker("Specialization", selection: $specialization) {
                        ForEach(specializations, id: \.self) { spec in
                            Text(spec)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                }

                Section(header: Text("Contact Information")) {
                    TextField("Phone", text: $phone)
                        .keyboardType(.phonePad)
                    TextField("Email", text: $email)
                        .keyboardType(.emailAddress)
                    
                    VStack(alignment: .leading) {
                        Text("Address").font(.subheadline).foregroundColor(.gray)
                        TextEditor(text: $address)
                            .frame(minHeight: 100)
                    }
                }

                Section(header: Text("Degrees")) {
                    ForEach(degrees.indices, id: \.self) { index in
                        HStack {
                            Button(action: {
                                removeDegree(at: index)
                            }) {
                                Image(systemName: "minus.circle.fill")
                                    .foregroundColor(.red)
                            }
                            TextField("Degree", text: $degrees[index])
                        }
                    }
                    Button(action: addNewDegree) {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                                .foregroundColor(.green)
                            Text("Add degree")
                        }
                    }
                }

                Section(header: Text("Professional Details")) {
                    TextField("Experience (years)", text: $experience)
                        .keyboardType(.numberPad)
                    TextField("Medical License ID", text: $medicalLicenseId)
                }

                Section(header: Text("Bank Details")) {
                    TextField("Bank Account No.", text: $bankAccountNumber)
                        .keyboardType(.numberPad)
                }
            }
            .navigationTitle("Add Doctor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        saveDoctorToFirestore()
                    }
                    .disabled(!isFormComplete)
                }
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(selectedImage: $selectedImage, sourceType: sourceType)
            }
            .actionSheet(isPresented: $showActionSheet) {
                ActionSheet(title: Text("Choose Photo"), buttons: [
                    .default(Text("Take Photo")) {
                        sourceType = .camera
                        showImagePicker = true
                    },
                    .default(Text("Choose from Library")) {
                        sourceType = .photoLibrary
                        showImagePicker = true
                    },
                    .cancel()
                ])
            }
        }
    }

    private func saveDoctorToFirestore() {
        let db = Firestore.firestore()
        let doctorId = UUID().uuidString

        var doctorData: [String: Any] = [
            "firstName": firstName,
            "lastName": lastName,
            "specialization": specialization,
            "phone": phone,
            "email": email,
            "address": address,
            "experience": experience,
            "medicalLicenseId": medicalLicenseId,
            "bankAccountNumber": bankAccountNumber,
            "degrees": degrees,
            "hospitalId": hospitalId,
            "doctorId": doctorId
        ]

        if let image = selectedImage {
            uploadDoctorImage(image, doctorId: doctorId) { imageUrl in
                doctorData["profileImageUrl"] = imageUrl
                db.collection("doctors").document(doctorId).setData(doctorData) { error in
                    if let error = error {
                        print("Error adding doctor: \(error.localizedDescription)")
                    } else {
                        print("Doctor added successfully!")
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        } else {
            db.collection("doctors").document(doctorId).setData(doctorData) { error in
                if let error = error {
                    print("Error adding doctor: \(error.localizedDescription)")
                } else {
                    print("Doctor added successfully!")
                    presentationMode.wrappedValue.dismiss()
                }
            }
        }
    }

    private func uploadDoctorImage(_ image: UIImage, doctorId: String, completion: @escaping (String) -> Void) {
        let storageRef = Storage.storage().reference().child("doctor_images/\(doctorId).jpg")
        guard let imageData = image.jpegData(compressionQuality: 0.75) else { return }

        storageRef.putData(imageData, metadata: nil) { _, error in
            if let error = error {
                print("Error uploading image: \(error.localizedDescription)")
                completion("")
                return
            }

            storageRef.downloadURL { url, _ in
                completion(url?.absoluteString ?? "")
            }
        }
    }

    private func addNewDegree() {
        degrees.append("")
    }

    private func removeDegree(at index: Int) {
        degrees.remove(at: index)
    }
    struct ImagePicker: UIViewControllerRepresentable {
        @Binding var selectedImage: UIImage?
        var sourceType: UIImagePickerController.SourceType

        func makeCoordinator() -> Coordinator {
            return Coordinator(self)
        }

        class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
            let parent: ImagePicker

            init(_ parent: ImagePicker) {
                self.parent = parent
            }

            func imagePickerController(_ picker: UIImagePickerController,
                                       didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
                if let image = info[.originalImage] as? UIImage {
                    parent.selectedImage = image
                }
                picker.dismiss(animated: true)
            }

            func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
                picker.dismiss(animated: true)
            }
        }

        func makeUIViewController(context: Context) -> UIImagePickerController {
            let picker = UIImagePickerController()
            picker.delegate = context.coordinator
            picker.sourceType = sourceType
            picker.allowsEditing = true
            return picker
        }

        func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    }
}


// **Preview**
struct AddDoctor_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            AddDoctor()
        }
    }
}
