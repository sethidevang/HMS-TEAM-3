
import SwiftUI

struct AdminChangePassword: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var oldPassword: String = ""
    @State private var newPassword: String = ""
    @State private var confirmNewPassword: String = ""
    
    // Computed property to check if all fields are filled
    private var isFormValid: Bool {
        return !oldPassword.isEmpty && !newPassword.isEmpty && !confirmNewPassword.isEmpty
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Old Password")
                .font(.headline)
            SecureField("Enter Old Password", text: $oldPassword)
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 1)
            
            Text("New Password")
                .font(.headline)
            SecureField("Enter New Password", text: $newPassword)
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 1)
            
            Text("Confirm New Password")
                .font(.headline)
            SecureField("Re-enter New Password", text: $confirmNewPassword)
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 1)
            
            Spacer()
            
            Button(action: savePassword) {
                Text("Save")
                    .foregroundColor(isFormValid ? .white : .gray) // Gray text when disabled
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isFormValid ? Color.red : Color.gray.opacity(0.5)) // Gray background when disabled
                    .cornerRadius(10)
            }
            .padding()
            .disabled(!isFormValid) // Disables button if form is not valid
        }
        .padding()
        .background(Color(.systemGray6))
        .navigationBarTitle("Change Password", displayMode: .inline)
    }
    
    func savePassword() {
        // Handle save action
    }
}

struct AdminChangePassword_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AdminChangePassword()
        }
    }
}
