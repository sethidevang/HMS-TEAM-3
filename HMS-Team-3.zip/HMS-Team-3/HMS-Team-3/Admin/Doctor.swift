import SwiftUI

// MARK: - Doctor Model
struct DoctorModel: Equatable,Identifiable {
    let id = UUID()
    var name: String
    var specialization: String
    var degrees: [String]
    var experience: String
    var phone: String
    var email: String
    var licenseId: String
    var bankAccount: String
    var address: String


    static func == (lhs: DoctorModel, rhs: DoctorModel) -> Bool {
        return lhs.name == rhs.name &&
               lhs.specialization == rhs.specialization &&
               lhs.degrees == rhs.degrees &&
               lhs.experience == rhs.experience &&
               lhs.phone == rhs.phone &&
               lhs.email == rhs.email &&
               lhs.licenseId == rhs.licenseId &&
               lhs.bankAccount == rhs.bankAccount &&
               lhs.address == rhs.address
    }
}


// MARK: - Doctor List View
struct Doctor: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var searchText = ""

    let doctors = [
        DoctorModel(name: "Shaun Murphy", specialization: "Cardiology", degrees: ["M.B.B.S.", "M.S.", "M.Ch."], experience: "35 years", phone: "9205 010 100", email: "doctor@gmail.com", licenseId: "012893199", bankAccount: "012893199XXXX", address: "Tower A, Unitech Business Park, Block - F, South City 1, Sector - 41, Gurgaon, Haryana - 122001"),
        DoctorModel(name: "Lisa Cuddy", specialization: "Endocrinology", degrees: ["M.D."], experience: "28 years", phone: "9205 020 200", email: "lisa@gmail.com", licenseId: "012893200", bankAccount: "012893200XXXX", address: "Sector 62, Noida, Uttar Pradesh - 201301"),
        DoctorModel(name: "Gregory House", specialization: "Nephrology", degrees: ["M.D.", "PhD"], experience: "30 years", phone: "9205 030 300", email: "house@gmail.com", licenseId: "012893300", bankAccount: "012893300XXXX", address: "New York, USA")
    ]

    // 🔍 Filter doctors based on search text
    var filteredDoctors: [DoctorModel] {
        if searchText.isEmpty {
            return doctors
        } else {
            return doctors.filter { doctor in
                doctor.name.localizedCaseInsensitiveContains(searchText) ||
                doctor.specialization.localizedCaseInsensitiveContains(searchText)
            }
        }
    }

    var body: some View {
            ZStack {
                Color(UIColor.systemGray6) // ✅ Set background color
                    .edgesIgnoringSafeArea(.all)

                VStack {
                    SearchBar(searchText: $searchText)
                        .padding(.bottom, 10)
                    List(filteredDoctors) { doctor in
                        ZStack {
                            DoctorCard(doctor: doctor)
                                .listRowBackground(Color.clear)

                            NavigationLink(destination: DoctorDetail(doctor: doctor)) {
                                EmptyView()
                            }
                            .opacity(0)
                        }
                        .listRowInsets(EdgeInsets())
                    }
                    .listStyle(PlainListStyle())
                    .background(Color.clear) // ✅ Keeps background consistent
                }
            }
            .navigationTitle("Doctors")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: AddDoctor()) {
                        Image(systemName: "plus")
                            .foregroundColor(.blue)
                    }
                }
            }
        }
}

// MARK: - Search Bar Component
struct SearchBar: View {
    @Binding var searchText: String

    var body: some View {
        HStack {
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                
                TextField("Search by Name or Specialization", text: $searchText)
                    .padding(.vertical, 8)
                    .autocapitalization(.none)

                Button(action: {
                    searchText = "" // Clear search
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                        .opacity(searchText.isEmpty ? 0 : 1)
                }
            }
            .padding(.horizontal, 10)
            .background(Color(red: 227/255, green: 227/255, blue: 233/255)) // ✅ Background color #E3E3E9
            .cornerRadius(10)
        }
        .padding(.horizontal)
    }
}


// MARK: - Doctor Card View
struct DoctorCard: View {
    let doctor: DoctorModel

    var body: some View {
        HStack {
            // Profile Image Placeholder
            Circle()
                .fill(Color.gray.opacity(0.3))
                .frame(width: 50, height: 50)

            // Doctor Details (Name, Specialization, Degrees)
            VStack(alignment: .leading) {
                Text(doctor.name)
                    .font(.headline)

                Text(doctor.specialization)
                    .font(.subheadline)
                    .foregroundColor(.gray)

                // ✅ Display degrees as a comma-separated list
                if !doctor.degrees.isEmpty {
                    Text(doctor.degrees.joined(separator: ", ")) // 🔥
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
            }

            Spacer()

            // Single disclosure indicator inside the card
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
        }
        .padding()
        .frame(height: 80)
        .background(Color.white)
        .cornerRadius(10)
        .shadow(color: Color.gray.opacity(0.3), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Preview
struct Doctor_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            Doctor()
        }
    }
}
