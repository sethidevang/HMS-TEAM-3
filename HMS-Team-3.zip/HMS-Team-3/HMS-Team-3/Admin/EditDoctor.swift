//
//  EditDoctor.swift
//  hms
//
//  Created by Yuktika Sood on 12/02/25.
//

import SwiftUI

struct EditDoctor: View {
    @State var doctor: DoctorModel
    @State private var originalValues: DoctorModel
    @State private var isEdited = false
    
    // ✅ Separate First and Last Name Fields
    @State private var firstName: String
    @State private var lastName: String
    
    // ✅ Store Specialization from Model
    @State private var specializations: [String]

    init(doctor: DoctorModel) {
        _doctor = State(initialValue: doctor)
        _originalValues = State(initialValue: doctor)
        
        let nameParts = doctor.name.split(separator: " ").map(String.init)
        _firstName = State(initialValue: nameParts.first ?? "")
        _lastName = State(initialValue: nameParts.dropFirst().joined(separator: " "))

        _specializations = State(initialValue: [doctor.specialization, "Cardiology", "Neurology", "Pediatrics", "Orthopedics"].removingDuplicates())
    }

    var body: some View {
        Form {
            /// **Edit Photo Section**
            Section {
                VStack {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                        .foregroundColor(.gray)
                    
                    Button(action: {
                        // Action for changing the photo
                    }) {
                        Text("Edit Photo")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.blue)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical)
            }
            .listRowBackground(Color.clear) // Removes background color

            /// **Personal Information**
            Section {
                TextField("First Name", text: $firstName)
                    .onChange(of: firstName) { _, _ in updateFullName() }

                TextField("Last Name", text: $lastName)
                    .onChange(of: lastName) { _, _ in updateFullName() }
                
                Picker("Specialization", selection: $doctor.specialization) {
                    ForEach(specializations, id: \.self) { spec in
                        Text(spec)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .onChange(of: doctor.specialization) { _, _ in checkForChanges() }
            }

            /// **Contact Information**
            Section {
                TextField("Phone", text: $doctor.phone)
                    .onChange(of: doctor.phone) { _, _ in checkForChanges() }
                TextField("Email", text: $doctor.email)
                    .onChange(of: doctor.email) { _, _ in checkForChanges() }
                
                /// **Multi-line Address Field Without Borders**
                VStack(alignment: .leading) {
                    Text("Address").font(.subheadline).foregroundColor(.gray)
                    TextEditor(text: $doctor.address)
                        .frame(minHeight: 100) // Allows multi-line input
                        .onChange(of: doctor.address) { _, _ in checkForChanges() }
                }
            }

            /// **Degrees**
            Section(header: Text("Degrees")) {
                ForEach(doctor.degrees.indices, id: \.self) { index in
                    HStack {
                        Button(action: {
                            removeDegree(at: index)
                        }) {
                            Image(systemName: "minus.circle.fill")
                                .foregroundColor(.red)
                        }
                        
                        TextField("Degree", text: $doctor.degrees[index])
                            .onChange(of: doctor.degrees[index]) { _, _ in checkForChanges() }
                    }
                }
                Button(action: {
                    addNewDegree()
                }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                            .foregroundColor(.green)
                        Text("Add degree")
                    }
                }
            }

            /// **Experience & Medical License ID**
            Section {
                TextField("Experience", text: $doctor.experience)
                    .onChange(of: doctor.experience) { _, _ in checkForChanges() }
                
                HStack {
                    Text("Medical License ID")
                        .foregroundColor(.gray)
                    Spacer()
                    Text(doctor.licenseId)
                        .foregroundColor(.primary)
                }
            }

            /// **Bank Details (Separate Section)**
            Section(header: Text("Bank Details")) {
                TextField("Bank Account No.", text: $doctor.bankAccount)
                    .onChange(of: doctor.bankAccount) { _, _ in checkForChanges() }
            }

            /// **Delete Doctor**
            Section {
                Button(action: {
                    // Remove doctor action
                }) {
                    Text("Remove Doctor")
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity, alignment: .center)
                }
            }
        }
        .navigationTitle("Edit Doctor")
        .navigationBarTitleDisplayMode(.inline) // Prevents large title
        .navigationBarItems(trailing:
            Button("Done") {
                // Handle save action
            }
            .disabled(!isEdited)
        )
    }

    private func checkForChanges() {
        isEdited = doctor != originalValues
    }

    private func updateFullName() {
        doctor.name = "\(firstName) \(lastName)".trimmingCharacters(in: .whitespaces)
        checkForChanges()
    }

    private func addNewDegree() {
        doctor.degrees.append("")
        checkForChanges()
    }

    private func removeDegree(at index: Int) {
        doctor.degrees.remove(at: index)
        checkForChanges()
    }
}

// MARK: - Array Extension to Remove Duplicates
extension Array where Element: Hashable {
    func removingDuplicates() -> [Element] {
        var set = Set<Element>()
        return filter { set.insert($0).inserted }
    }
}

// MARK: - Preview
struct EditDoctor_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            EditDoctor(doctor: DoctorModel(
                name: "Shaun Murphy",
                specialization: "Cardiology",
                degrees: ["M.B.B.S.", "M.S.", "M.Ch."],
                experience: "35 years",
                phone: "9205 010 100",
                email: "doctor@gmail.com",
                licenseId: "012893199",
                bankAccount: "012893199XXXX",
                address: "Tower A, Gurgaon"
            ))
        }
    }
}
