//
//  YourApp.swift
//  HMS-Team-3
//
//  Created by Devang Sethi on 11/02/25.
//

//import SwiftUI
//import FirebaseCore
//@main
//struct YourApp: App {
//    @UIApplicationDelegate var delegate: AppDelegate
//    
//    var body: some Scene {
//        WindowGroup {
//            ContentView()
//        }
//    }
//}
//#Preview {
//    YourApp()
//}
