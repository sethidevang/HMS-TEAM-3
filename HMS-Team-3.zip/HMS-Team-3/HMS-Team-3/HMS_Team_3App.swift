//
//  HMS_Team_3App.swift
//  HMS-Team-3
//
//  Created by Devang Sethi on 11/02/25.
//
import SwiftUI
import Firebase
@main
struct HMS_Team3App: App {
    init() {
            FirebaseApp.configure()
        }
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}

//import SwiftUI
//import Firebase
//@main
//struct HMS_Team_3App: App {
//    
//    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
//    
//    var body: some Scene {
//        WindowGroup {
//            ContentView()
//        }
//    }
//}
//class AppDelegate: NSObject, UIApplicationDelegate {
//    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
//        FirebaseApp.configure()
//        return true
//    }
//}
